package net.bitnine.hynix.conf;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {

}
